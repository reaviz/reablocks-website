import type { RadioTheme } from 'reablocks';

export const radioTheme: RadioTheme = {
  base: 'box-border leading-none group',
  radio: {
    base: `
          inline-flex justify-center items-center align-middle rounded-full cursor-pointer transition-colors border focus-visible:outline-none
          bg-selectors-colors-radio-not-selected-background-resting group-hover:bg-selectors-colors-radio-not-selected-background-hover group-focus-within:bg-selectors-colors-radio-not-selected-background-hover
          border-selectors-colors-radio-not-selected-stroke-resting group-hover:border-selectors-colors-radio-not-selected-stroke-hover group-focus-within:border-selectors-colors-radio-not-selected-stroke-hover
        `,
    checked: `
          bg-selectors-colors-radio-selected-background-resting group-hover:bg-selectors-colors-radio-selected-background-hover group-focus-within:bg-selectors-colors-radio-selected-background-hover
          border-selectors-colors-radio-selected-stroke-resting group-hover:border-selectors-colors-radio-selected-stroke-hover group-focus-within:border-selectors-colors-radio-selected-stroke-hover
        `,
    disabled:
      'cursor-not-allowed opacity-40 group-hover:bg-inherit group-focus-within:bg-inherit'
  },
  indicator: {
    base: 'rounded-full bg-selectors-colors-radio-selected-assets-base',
    disabled: 'cursor-not-allowed',
    sizes: {
      small: 'size-(--selectors-details-asset-size-radio-checkbox-sm)',
      medium: 'size-(--selectors-details-asset-size-radio-checkbox-sm)',
      large: 'size-(--selectors-details-asset-size-radio-checkbox-lg)'
    }
  },
  label: {
    base: 'w-full align-middle ml-(--selectors-details-space-between-horizontal-sm) text-selectors-colors-text-label-not-selected',
    clickable:
      'cursor-pointer group-hover:text-selectors-colors-text-label-selected group-focus-within:text-selectors-colors-text-label-selected',
    disabled: 'cursor-not-allowed opacity-40',
    checked: 'text-selectors-colors-text-label-selected'
  },
  sizes: {
    small: 'size-(--selectors-details-width-radio-checkbox-sm)',
    medium: 'size-(--selectors-details-width-radio-checkbox-sm)',
    large:
      'size-(--selectors-details-width-radio-checkbox-lg) p-(--selectors-details-vertical-padding-lg)'
  }
};
