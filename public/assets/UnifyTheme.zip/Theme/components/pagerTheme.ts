import type { PagerTheme } from 'reablocks';

export const pagerTheme: PagerTheme = {
  base: 'items-center flex user-select-none gap-5',
  pages: {
    base: 'inline-flex items-center gap-1 text-sm',
    page: {
      base: `
        text-xs text-buttons-colors-core-icon-ghost-text-resting py-2 min-w-8 transition-colors border
        bg-buttons-colors-core-icon-ghost-background-resting hover:bg-buttons-colors-core-icon-ghost-background-hover focus-visible:bg-buttons-colors-core-icon-ghost-background-hover
        border-buttons-colors-core-icon-ghost-stroke-resting hover:border-buttons-colors-core-icon-ghost-stroke-hover focus-visible:border-buttons-colors-core-icon-ghost-stroke-hover
      `,
      active:
        'text-buttons-colors-core-icon-ghost-text-selected font-bold disabled:cursor-default disabled:opacity-100 disabled:bg-buttons-colors-core-icon-ghost-background-selected disabled:text-buttons-colors-core-icon-ghost-text-selected'
    }
  },
  ellipsis:
    'cursor-pointer text-buttons-colors-core-icon-ghost-text-resting min-w-8 flex items-baseline justify-center leading-8',
  pagerDisplayItems: 'text-xs',
  itemsDisplay: 'text-buttons-colors-core-icon-ghost-text-selected font-sm',
  showPageRange: '',
  totalCount: '',
  control: `
    min-size-8 p-2 [&>svg]:size-4 text-buttons-colors-core-icon-secondary-assets-resting transition-colors border
    bg-buttons-colors-core-icon-secondary-background-resting hover:bg-buttons-colors-core-icon-secondary-background-hover focus-visible:bg-buttons-colors-core-icon-secondary-background-hover disabled:bg-buttons-colors-core-icon-secondary-background-resting
    border-buttons-colors-core-icon-secondary-stroke-resting hover:border-buttons-colors-core-icon-secondary-stroke-hover focus-visible:border-buttons-colors-core-icon-secondary-stroke-hover disabled:border-buttons-colors-core-icon-secondary-stroke-resting
  `,
  firstPage: '',
  prevPage: '',
  lastPage: '',
  nextPage: ''
};
